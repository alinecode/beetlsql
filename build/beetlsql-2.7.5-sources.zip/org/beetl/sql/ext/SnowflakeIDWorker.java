package org.beetl.sql.ext;

import org.beetl.sql.core.IDAutoGen;

public class SnowflakeIDWorker  {

	    private long workerId;
	    private long datacenterId;
	    private long sequence = 0L;
	 
	    //日期，2010年，用到2080年
	    public  static long twepoch = 1288834974657L;
	 
	    private long workerIdBits = 5L;
	    private long datacenterIdBits = 5L;
	    //31
	    private long maxWorkerId = -1L ^ (-1L << workerIdBits);
	    //31
	    private long maxDatacenterId = -1L ^ (-1L << datacenterIdBits);
	    private long sequenceBits = 12L;
	 
	    private long workerIdShift = sequenceBits;
	    private long datacenterIdShift = sequenceBits + workerIdBits;
	    private long timestampLeftShift = sequenceBits + workerIdBits + datacenterIdBits;
	    private long sequenceMask = -1L ^ (-1L << sequenceBits);
	 
	    private long lastTimestamp = -1L;
	    
	    public SnowflakeIDWorker(long workerId, long datacenterId) {
	        // sanity check for workerId
	        if (workerId > maxWorkerId || workerId < 0) {
	            throw new IllegalArgumentException(String.format("worker Id can't be greater than %d or less than 0", maxWorkerId));
	        }
	        if (datacenterId > maxDatacenterId || datacenterId < 0) {
	            throw new IllegalArgumentException(String.format("datacenter Id can't be greater than %d or less than 0", maxDatacenterId));
	        }
	        this.workerId = workerId;
	        this.datacenterId = datacenterId;
	    }
	 
	    public synchronized long nextId() {
	        long timestamp = timeGen();
	 
	        if (timestamp < lastTimestamp) {
	            throw new RuntimeException(String.format("Clock moved backwards.  Refusing to generate id for %d milliseconds", lastTimestamp - timestamp));
	        }
	 
	        if (lastTimestamp == timestamp) {
	            sequence = (sequence + 1) & sequenceMask;
	            if (sequence == 0) {
	                timestamp = tilNextMillis(lastTimestamp);
	            }
	        } else {
	            sequence = 0L;
	        }
	 
	        lastTimestamp = timestamp;
	 
	        return ((timestamp - twepoch) << timestampLeftShift) | (datacenterId << datacenterIdShift) | (workerId << workerIdShift) | sequence;
	    }
	 
	    protected long tilNextMillis(long lastTimestamp) {
	        long timestamp = timeGen();
	        while (timestamp <= lastTimestamp) {
	            timestamp = timeGen();
	        }
	        return timestamp;
	    }
	 
	    protected long timeGen() {
	        return System.currentTimeMillis();
	    }
	    
	
	
}
